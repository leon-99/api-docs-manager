@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="container">
            <div class="cards my-5">
                @foreach ($defs as $def)
                    <div class="card mt-3">
                        <div class="card-header">
                            <h5 style="font-weight: 600">{{ $def->title }}</h5>
                            @if ($def->status == 'Completed')
                                <p>Feature status: <span class="text-success">{{ $def->status }}</span></p>
                            @elseif ($def->status == 'Planned')
                                <p>Feature status: <span style="color: rgb(219, 155, 37)">{{ $def->status }}</span></p>
                            @elseif ($def->status == 'On Hold')
                                <p>Feature status: <span style="color: rgb(219, 155, 37)">{{ $def->status }}</span></p>
                            @else
                                <p>Feature status: <span class="text-primary">{{ $def->status }}</span></p>
                            @endif

                            <small class="text-muted">written by {{ $def->modify_by }}</small>
                        </div>
                        <div class="card-body">
                            <p class="card-text" style="white-space:pre-wrap">{{ $def->content }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
