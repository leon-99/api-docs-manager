@extends('layouts.app')

@section('content')
    <div class="container">

        @if (session('success'))
            <div class="alert alert-success my-3"><span class="material-symbols-outlined" style="vertical-align: middle">
                    done
                </span> {{ @session('success') }}</div>
        @endif

        <div class="row mt-5">
            <div class="col-md-4">
                <table class="table table-hover border">
                    <thead>
                        <tr>
                            <th scope="col">Title</th>
                            <th scope="col">Count</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($counts as $key => $value)
                            <tr>
                                <td>{{ $key }}</td>
                                <td> {{ $value }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="col-md-8">
                 <h5 class="text-center">Activity Chart</h5>
            <div id="calendar_basic"></div>
            </div>

        </div>

        <div class="row mt-3">
            <div class="col-md-4">
                <canvas id="created" class="border"></canvas>
            </div>
            <div class="col-md-4">
                <canvas id="updated" class="border"></canvas>
            </div>
            <div class="col-md-4">
                <canvas id="by" class="border"></canvas>
            </div>
            <hr>
        </div>
        <div class="row mt-5 ">

        </div>

        <div class="row ">
            <div class="col-md-12">
                <h5 class="text-center">Documentations deleted records.</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Group</th>
                            <th scope="col">Name</th>
                            <th scope="col">User</th>
                            <th scope="col">Time</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($deletedRecords as $d)
                            <tr>
                                <th>{{ $d->doc->group }}</th>
                                <td>{{ $d->doc->name }}</td>
                                <td>{{ $d->user->name }}</td>
                                <td>{{ $d->created_at }}</td>
                                <td>
                                    <form action="{{ route('docs.restore', $d->doc_id) }}" method="POST">
                                        @csrf
                                        <button class="btn btn-sm" type="submit">
                                            <span class="material-symbols-outlined" style="vertical-align: middle">
                                                restore_from_trash
                                            </span> Restore</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>



    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script>
        google.charts.load("current", {
            packages: ["calendar"]
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var dataTable = new google.visualization.DataTable();
            dataTable.addColumn({
                type: 'date',
                id: 'Date'
            });
            dataTable.addColumn({
                type: 'number',
                id: 'Count'
            });
            data = {{ Js::from($calenderData) }}

            Object.entries(data).forEach(([key, value]) => {
                // console.log(value.date)
                dataTable.addRow([new Date(value.date), value.count]);
            })

            var chart = new google.visualization.Calendar(document.getElementById('calendar_basic'));

            var options = {
                height: 200,
                colorAxis: {
                    minValue: 0,
                    colors: ['#003300', '#00FF00']
                },

                calendar: {
                    cellSize: 15,
                    cellColor: {
                        stroke: 'green',
                        strokeOpacity: 0.5,
                        strokeWidth: 1,
                        strokeColor: '#fff',
                        strokeOpacity: 1,
                        strokeWidth: 0.1
                    },
                    // cellColor: {
                    //     stroke: 'green', // Color the border of the squares.
                    //     strokeOpacity: 0.5, // Make the borders half transparent.
                    //     strokeWidth: 0.1 // ...and two pixels thick.
                    // },
                    focusedCellColor: {
                        stroke: 'green',
                        strokeOpacity: 0.5,
                        strokeWidth: 3
                    }
                },
            };

            chart.draw(dataTable, options);
        }

        //
        (async function() {
            let data = {{ Js::from($items) }};

            new Chart(document.getElementById("created"), {
                type: "line",
                data: {
                    labels: data.map((row) => row.date),
                    datasets: [{
                        label: "Docs created",
                        borderColor: '#00880005',
                        backgroundColor: '#00880050',
                        data: data.map((row) => row.count),
                    }, ],
                },
            });
        })();

        (async function() {
            let data = {{ Js::from($updated) }};

            new Chart(document.getElementById("updated"), {
                type: "line",
                data: {
                    labels: data.map((row) => row.date),
                    datasets: [{
                        label: "Docs updated",
                        borderColor: '#00880005',
                        backgroundColor: '#00880050',
                        data: data.map((row) => row.count),
                    }, ],
                },
            });
        })();

        (async function() {
            let data = {{ Js::from($by) }};

            new Chart(document.getElementById("by"), {
                type: "pie",
                data: {
                    labels: data.map((row) => row.modify_by),
                    datasets: [{
                        label: "Docs modified by",
                        borderColor: '#00880005',
                        backgroundColor: ['#00880050', '#00008850'],
                        data: data.map((row) => row.count),
                    }, ],
                },
            });
        })();
    </script>
@endsection
