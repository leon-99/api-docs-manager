@extends('layouts.app')

@section('content')
    <h1>test</h1>
@endsection
