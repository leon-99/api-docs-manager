@extends('layouts.app')

@section('content')
    <div class="d-flex">
        <div class="col-3 position-fixed"
            style="width: 250px; height: 100vh; border-right: 1px solid rgb(190, 190, 190); overflow-y: scroll">
            <div class="links mx-2 d-flex flex-column my-4">
                @foreach ($items as $groupKey => $itemGroup)
                    {{--  --}}
                    <ul class="list-group">
                        <li class="list-group-item bg-dark text-light py-1 rounded-0" data-bs-toggle="collapse"
                            data-bs-target="#list-group-{{ $groupKey }}" style="cursor: pointer; transition: all ease 0.5s" id="{{$groupKey}}"
                            onclick="rotateArrow('{{$groupKey}}arrow')">{{ $groupKey }}
                            <span class="material-symbols-outlined" style="float: right; transition: all ease 0.5s"
                                id="{{$groupKey}}arrow">
                                expand_more
                            </span>
                        </li>
                        <div class="collapse" id="list-group-{{ $groupKey }}">
                            @foreach ($itemGroup as $listGroupItem)
                                @if ($listGroupItem->desc[0] == '!')
                                    <a class="list-group-item hover-bg-gray text-danger py-1"
                                        href="#{{ $groupKey }}{{ $listGroupItem->name }}">!
                                        {{ $listGroupItem->name }}</a>
                                @else
                                    <a class="list-group-item hover-bg-gray py-1"
                                        href="#{{ $groupKey }}{{ $listGroupItem->name }}">{{ $listGroupItem->name }}</a>
                                @endif
                            @endforeach
                        </div>
                    </ul>


                    {{--  --}}
                @endforeach
                <div class="end-block my-4"></div>
            </div>
        </div>

        {{-- main side --}}
        <div class="col-9 px-5 my-3" style="margin-left: 250px;">
            <br id="top">
            @if (session('success'))
                <div class="alert alert-light">{{ @session('success') }}</div>
            @endif

            {{-- unstables --}}
            @foreach ($unstable as $unstableKey => $unstableItem)
                <div class="section my-3" id="{{ $unstableKey }}">

                    <p class="h3 text-danger" data-bs-toggle="collapse" data-bs-target="#{{ $unstableKey }}-collapse"
                        aria-expanded="false" aria-controls="{{ $unstableKey }}-collapse" style="cursor: pointer;">
                        <span>#</span> {{ $unstableKey }} / Unstable Routes
                        <span class="material-symbols-outlined me-3" style="float: right">
                            expand_more
                        </span>
                    </p>
                    <ul class="list-group collapse ms-4" id="{{ $unstableKey }}-collapse" aria-expanded="false"
                        aria-controls="{{ $unstableKey }}-collapse">


                        @foreach ($unstableItem as $unstableI)
                            <li class="list-group-item my-3" id="{{ $unstableKey }}{{ $unstableI->name }}">
                                <div class="dropup">
                                    <span class="material-symbols-outlined" type="button" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false" style="float: right">
                                        more_horiz
                                    </span>

                                    <div class="dropdown-menu">
                                        <button class=" dropdown-item text-danger" data-bs-toggle="modal"
                                            data-bs-target="#delete{{ $unstableI->id }}">delete</button>

                                        <a href="{{ route('doc.edit', $unstableI->id) }}" class=" dropdown-item">edit</a>
                                    </div>
                                </div>
                                <h4 class="mt-3" style="font-weight: 600">
                                    @if ($unstableI->method == 'POST')
                                        <span
                                            class="badge badge-success bg-warning text-dark">{{ $unstableI->method }}</span>
                                    @else
                                        <span class="badge badge-success bg-success">{{ $unstableI->method }}</span>
                                    @endif
                                    <span>{{ $unstableKey }}/{{ $unstableI->name }}</span>
                                </h4>

                                 {{-- by --}}
                                 @if ($unstableI->modified == 0)
                                 <p class="text-muted">marked <span>{{ $unstableI->created_at->diffForHumans() }}</span> by
                                     {{ $unstableI->modify_by }}</p>
                                 @else
                                 <p class="text-muted">marked <span>{{ $unstableI->updated_at->diffForHumans() }}</span> by
                                     {{ $unstableI->modify_by }}</p>
                                 @endif

                                <!-- Modal -->
                                <div class="modal fade" id="delete{{ $unstableI->id }}" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">

                                            <div class="modal-body">
                                                Are you sure you want to delete "{{ $unstableI->group }}
                                                {{ $unstableI->name }}"
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm"
                                                    data-bs-dismiss="modal">Close</button>
                                                <form action="{{ route('doc.destroy', $unstableI->id) }}" method="post">
                                                    @csrf
                                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                    <p class="my-4 text-danger font-weight-bold" style="white-space:pre-wrap">{{ $unstableI->desc }}</p>

                                <div class="my-4">
                                    <pre><code>{{ $unstableI->url }}</code></pre>
                                </div>
                                <h5><b>Header</b></h5>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Key</th>
                                            <th scope="col">Value</th>
                                            <th scope="col">Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($unstableI->headers as $UnstableHeader)
                                            <tr>
                                                <td>{{ $UnstableHeader->key }}</td>
                                                <td>{{ $UnstableHeader->value }}</td>
                                                <td>{{ $UnstableHeader->desc }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                                <ul class="nav nav-tabs" id="myTab{{ $unstableI->id }}" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link text-dark active" id="home-tab" data-bs-toggle="tab"
                                            data-bs-target="#home{{ $unstableI->id }}" type="button" role="tab"
                                            aria-controls="home" aria-selected="true">Request</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link text-dark" id="profile-tab" data-bs-toggle="tab"
                                            data-bs-target="#profile{{ $unstableI->id }}" type="button" role="tab"
                                            aria-controls="profile" aria-selected="false">Response</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home{{ $unstableI->id }}" role="tabpanel"
                                        aria-labelledby="home-tab">

                                        @foreach ($unstableI->bodies as $unstableB)
                                            <pre class="mt-3"><code>{{ $unstableB->value }}</code></pre>
                                        @endforeach
                                    </div>
                                    <div class="tab-pane fade" id="profile{{ $unstableI->id }}" role="tabpanel"
                                        aria-labelledby="profile-tab">

                                        @foreach ($unstableI->res as $unstableResp)
                                            <pre class="mt-3"><code>{{ $unstableResp->desc }}</code></pre>
                                        @endforeach
                                    </div>
                                </div>
                            </li>
                            <hr>
                        @endforeach
                    </ul>
                </div>
                <hr>
            @endforeach

            {{-- normals --}}
            @foreach ($items as $key => $item)
                <div class="section my-3" id="{{ $key }}">

                    <p class="h3" data-bs-toggle="collapse" data-bs-target="#{{ $key }}-collapse"
                        aria-expanded="true" aria-controls="{{ $key }}-collapse" style="cursor: pointer;">
                        # {{ $key }}
                        <span class="material-symbols-outlined me-3" style="float: right">
                            expand_more
                        </span>
                    </p>
                    <ul class="list-group collapse show ms-4" id="{{ $key }}-collapse" aria-expanded="false"
                        aria-controls="{{ $key }}-collapse">
                        @foreach ($item as $i)
                            <br id="{{ $key }}{{ $i->name }}">
                            <li class="list-group-item my-3">
                                <div class="dropup">
                                    <span class="material-symbols-outlined" type="button" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false" style="float: right">
                                        more_horiz
                                    </span>

                                    <div class="dropdown-menu">

                                        <button class=" dropdown-item text-danger" data-bs-toggle="modal"
                                            data-bs-target="#delete{{ $i->id }}">delete</button>

                                        <a href="{{ route('doc.edit', $i->id) }}" class=" dropdown-item">edit</a>
                                    </div>
                                </div>
                                <h4 class="mt-3" style="font-weight: 600">
                                    @if ($i->method == 'POST')
                                        <span class="badge badge-success bg-warning text-dark">{{ $i->method }}</span>
                                    @else
                                        <span class="badge badge-success bg-success">{{ $i->method }}</span>
                                    @endif
                                    <span>{{ $key }}/{{ $i->name }}</span>
                                </h4>

                                {{-- by --}}
                                @if ($i->modified == 0)
                                <p class="text-muted">
                                    <span class="material-symbols-outlined" style="vertical-align: middle">
                                        schedule
                                        </span>
                                    created <span>{{ $i->created_at->diffForHumans() }}</span> by
                                    {{ $i->modify_by }}</p>
                                @else
                                <p class="text-muted">
                                    <span class="material-symbols-outlined" style="vertical-align: middle">
                                        update
                                        </span>
                                    updated <span>{{ $i->updated_at->diffForHumans() }}</span> by
                                    {{ $i->modify_by }}</p>
                                @endif


                                <!-- Modal -->
                                <div class="modal fade" id="delete{{ $i->id }}" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">

                                            <div class="modal-body">
                                                Are you sure you want to delete "{{ $i->group }} {{ $i->name }}"
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm"
                                                    data-bs-dismiss="modal">Close</button>
                                                <form action="{{ route('doc.destroy', $i->id) }}" method="post">
                                                    @csrf
                                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                @if ($i->desc[0] == '!')
                                    <p class="my-4 text-danger font-weight-bold" style="white-space:pre-wrap">
                                        {{ $i->desc }}</p>
                                @elseif ($i->desc[0] == '?')
                                    <p class="my-4 font-weight-bold" style="white-space:pre-wrap; color: #ac8206">
                                        {{ $i->desc }}</p>
                                @else
                                    <p class="my-4" style="white-space:pre-wrap">{{ $i->desc }}</p>
                                @endif

                                <div class="my-4">
                                    <pre><code>{{ $i->url }}</code></pre>
                                </div>
                                <h5><b>Header</b></h5>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Key</th>
                                            <th scope="col">Value</th>
                                            <th scope="col">Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($i->headers as $header)
                                            <tr>
                                                <td>{{ $header->key }}</td>
                                                <td>{{ $header->value }}</td>
                                                <td>{{ $header->desc }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                                <ul class="nav nav-tabs" id="myTab{{ $i->id }}" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link text-dark active" id="home-tab" data-bs-toggle="tab"
                                            data-bs-target="#home{{ $i->id }}" type="button" role="tab"
                                            aria-controls="home" aria-selected="true"> <span class="material-symbols-outlined ms-2" style="vertical-align: middle;">
                                                data_object
                                                </span> Request</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link text-dark" id="profile-tab" data-bs-toggle="tab"
                                            data-bs-target="#profile{{ $i->id }}" type="button" role="tab"
                                            aria-controls="profile" aria-selected="false">Response</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home{{ $i->id }}" role="tabpanel"
                                        aria-labelledby="home-tab">

                                        @foreach ($i->bodies as $b)
                                            <pre class="mt-3"><code>{{ $b->value }}</code></pre>
                                        @endforeach
                                    </div>
                                    <div class="tab-pane fade" id="profile{{ $i->id }}" role="tabpanel"
                                        aria-labelledby="profile-tab">

                                        @foreach ($i->res as $resp)
                                            <pre class="mt-3"><code>{{ $resp->desc }}</code></pre>
                                        @endforeach
                                    </div>
                                </div>
                            </li>
                            <hr>
                        @endforeach
                    </ul>
                </div>
                <hr>
            @endforeach
        </div>
    </div>

    {{-- scroll top --}}
    <a class="position-fixed scroll-top bg-dark text-light" href="#top">
        <span class="material-symbols-outlined">
            expand_less
        </span>
    </a>

@endsection
