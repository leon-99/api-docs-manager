@extends('layouts.app')

@section('content')
    <div class="container pb-5">
        @if (session('failed'))
            <div class="alert alert-danger mt-3">{{ @session('failed') }}</div>
        @endif

        <h3 class="my-4">Update "{{ $item->group }}, {{ $item->name }}"</h3>

        <form action="{{ route('doc.update') }}" method="post" id="form">
            @csrf
            <input type="hidden" value="{{ $item->id }}" name="id">
            <div class="row mb-3">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Group</label>
                    <input type="text" class="form-control" id="group" placeholder="Group" name="group"
                        value="{{ $item->group }}">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Name</label>
                    <input type="text" class="form-control" id="name" placeholder="name" name="name"
                        value="{{ $item->name }}">
                </div>
            </div>
            <div class="row mb-3">
                <div class="form-group col-md-6">
                    <label for="endpoint">Method</label>
                    <input type="text" class="form-control" id="method" placeholder="GET/POST" name="method"
                        value="{{ $item->method }}">
                </div>
                <div class="form-group col-md-6">
                    <label for="endpoint">Endpoint</label>
                    <input type="text" class="form-control" id="endpoint" placeholder="endpoint" name="endpoint"
                        value="{{ $item->url }}">
                </div>
            </div>
            <div class="form-group mb-3">
                <label for="headers">Description</label>
                <textarea type="text" class="form-control" id="desc" name="desc">{{ $item->desc }}</textarea>
                <small>start with ! to mark this as unstable or unused route.</small>
                <br>
                @if (session('header_error'))
                    <small class="text-danger">{{ session('header_error') }}</small>
                @endif
            </div>
            <div class="form-group mb-3">
                <label for="headers">Headar</label>
                <input type="text" class="form-control" id="headers"
                    placeholder="authorition:uicdeiui637,accept:application/json" name="inputh" value="Auth:Barear Token">
                <small>This column works in key value pairs. example name:alice,age:22</small>
            </div>
            <div class="form-group mb-3">
                <label for="body">Body</label>
                <textarea type="text" class="form-control" id="body" placeholder="user:1,item_id:2" name="inputb"
                    rows="5">{{ $item->bodies[0]->value }}</textarea>
            </div>
            <div class="form-group mb-3">
                <label for="response">Response</label>
                <textarea type="text" class="form-control" id="response" placeholder="[{id:1, text: hello}]" name="inputr"
                    rows="10">{{ $item->res[0]->desc }}</textarea>
            </div>
            <button type="submit" class="btn btn-success btn-sm">Save</button>
            <p class="col-md-6 my-2 ps-auto text-success d-inline ms-2">Press Ctrl+Enter to save.</p>
        </form>
    </div>

    <script>
        window.addEventListener('keydown', evt => {
            if (evt.key === 'Enter' && evt.ctrlKey) {
                document.querySelector("#form").submit();
            }
        });
    </script>
@endsection
