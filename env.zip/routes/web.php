<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Mockery\Generator\MockDefinition;
use App\Http\Controllers\DocController;
use App\Http\Controllers\DefinitionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::group(['middleware' => ['auth'], 'controller' => DocController::class], function () {
    Route::get('/', 'index')->name('docs.index');
    Route::post('/search', 'search')->name('docs.search');
    Route::get('/create', 'create')->name('doc.create');
    Route::post('/store', 'store')->name('doc.store');
    Route::get('/edit{id}', 'edit')->name('doc.edit');
    Route::post('/update', 'update')->name('doc.update');
    Route::post('/destroy/{id}', 'destroy')->name('doc.destroy');
    Route::post('/restore/{id}', 'restore')->name('docs.restore');
    Route::get('/reports', 'report')->name('docs.reports');
});

Route::group(['middleware' => ['auth'], 'controller' => DefinitionController::class, 'prefix' => 'definitions'], function () {
    Route::get('/', 'index')->name('def.index');
    // Route::get('/create', 'create')->name('doc.create');
    // Route::post('/store', 'store')->name('doc.store');
    // Route::get('/edit{id}', 'edit')->name('doc.edit');
    // Route::post('/update', 'update')->name('doc.update');
    // Route::post('/destroy/{id}', 'destroy')->name('doc.destroy');
});


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// bug test
