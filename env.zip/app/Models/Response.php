<?php

namespace App\Models;

use App\Models\Doc;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Response extends Model
{
    use HasFactory;

    protected $fillable = ['desc', 'doc_id'];

    public function doc()
    {
        return $this->belongsTo(Doc::class);
    }
}
