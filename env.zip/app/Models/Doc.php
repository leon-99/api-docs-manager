<?php

namespace App\Models;

use App\Models\Body;
use App\Models\Header;
use App\Models\Response;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\SoftDeletes;

class Doc extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'group',
        'method',
        'url',
        'input_data'
    ];

    protected function group() : Attribute
    {
        return Attribute::make(
            set: fn (string $value) => str_replace(' ', '-', $value)
        );
    }

    public function headers()
    {
        return $this->hasMany(Header::class);
    }

    public function bodies()
    {
        return $this->hasMany(Body::class);
    }

    public function res()
    {
        return $this->hasMany(Response::class);
    }
}
