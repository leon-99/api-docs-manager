<?php

namespace App\Models;

use App\Models\Doc;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Body extends Model
{
    use HasFactory;

    protected $table = 'bodies';

    protected $fillable = ['key', 'value', 'doc_id', 'desc'];

    public function doc()
    {
        return $this->belongsTo(Doc::class);
    }
}
