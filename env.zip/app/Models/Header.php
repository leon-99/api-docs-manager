<?php

namespace App\Models;

use App\Models\Doc;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Header extends Model
{
    use HasFactory;

    protected $table = 'headers';

    protected $fillable = ['key', 'value', 'doc_id', 'desc'];

    public function doc()
    {
        return $this->belongsTo(Doc::class);
    }
}
