<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Definition;

class DefinitionController extends Controller
{
    public function index()
    {
        $defs = Definition::orderBy('status_code')->get();
        return view('definitions', [
            'defs' => $defs
        ]);
    }
}
