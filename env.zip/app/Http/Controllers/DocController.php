<?php

namespace App\Http\Controllers;

use Carbon\Carbon;

use App\Models\Doc;
use App\Models\Body;
use App\Models\User;
use App\Models\Header;
use Illuminate\Http\Request;
use App\Models\DeletedRecord;
use Illuminate\Support\Facades\DB;
use App\Models\Response as ResponseModel;

class DocController extends Controller
{
    public function index()
    {
        // $groups = Doc::distinct('group')->orderBy('group')->pluck('group');
        $unstable = Doc::where('desc', 'like', '!%')->with('headers', 'bodies', 'res')->orderBy('method')->orderBy('group')->orderBy('name')->get()->groupBy('group');
        $discuss = Doc::where('desc', 'like', '?%')->with('headers', 'bodies', 'res')->orderBy('method')->orderBy('group')->orderBy('name')->get()->groupBy('group');

        $items = Doc::with('headers', 'bodies', 'res')->orderBy('method')->orderBy('group')->orderBy('name')->get()->groupBy('group');


        return view('docs', [
            'items' => $items,
            'unstable' => $unstable,
            'discuss' => $discuss
        ]);
    }

    public function search(Request $request)
    {
        $items = Doc::where('name', 'LIKE', '%'.$request->keyword.'%')
            ->orWhere('group', 'LIKE', '%'.$request->keyword.'%')
            ->orWhere('url', 'LIKE', '%'.$request->keyword.'%')
            ->orWhere('modify_by', 'LIKE', '%'.$request->keyword.'%')
            ->with('headers', 'bodies', 'res')
            ->orderBy('method')->orderBy('group')->orderBy('name')
            ->get()
            ->groupBy('group');

        return view('searchresults', [
            "items" => $items
        ]);
    }

    public function create()
    {
        return view('create');
    }

    public function store(Request $request)
    {

        $headers = $this->transformStringToAarray($request->inputh);

        if(!$headers) {
            return back()->with('header_error', "Invalid format");
        }

        Db::beginTransaction();
        try {
            $doc = new Doc();
            $doc->name = $request->name;
            $doc->modify_by = auth()->user()->name;
            $doc->group = $request->group;
            $doc->desc = $request->desc;
            $doc->method =  $request->method;
            $doc->url = $request->endpoint;
            $doc->save();

            foreach ($headers as $header) {
                foreach ($header as $key => $value) {
                    Header::create([
                        'key' => $key,
                        'value' => $value,
                        'doc_id' => $doc->id,
                        'desc' => ''
                    ]);
                }
            }

            $body = new Body();
            $body->value = $request->inputb;
            $body->doc_id = $doc->id;
            $body->save();

            ResponseModel::create([
                'desc' => $request->response,
                'doc_id' => $doc->id
            ]);

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->route('doc.create')->with("failed", "Route create failed.");
        }


        return redirect()->route('docs.index')->with('success', "" . $doc->group . " " . $doc->name . " route added successfully.");
    }

    public function edit($id)
    {
        $doc = Doc::where('id', $id)->with('headers', 'bodies', 'res')->first();
        return view('update', [
            'item' => $doc
        ]);
    }

    public function update(Request $request)
    {

        $headers = $this->transformStringToAarray($request->inputh);

        if(!$headers) {
            return back()->with('header_error', "Invalid format");
        }

        Db::beginTransaction();
        try {
        $doc = Doc::find($request->id);
        $doc->name = $request->name;
        $doc->modify_by = auth()->user()->name;
        $doc->modified = 1;
        $doc->group = $request->group;
        $doc->desc = $request->desc;
        $doc->method =  $request->method;
        $doc->url = $request->endpoint;
        $doc->modify_by = auth()->user()->name;
        $doc->save();

        foreach ($headers as $header) {
            foreach ($header as $key => $value) {
                $header = Header::where('doc_id', $request->id)->first();
                $header->key = $key;
                $header->value = $value;
                $header->doc_id = $request->id;
                $header->desc = '';
                $header->save();
            }
        }

        $body = Body::where('doc_id', $request->id)->first();
        $body->value = $request->inputb;
        $body->doc_id = $doc->id;
        $body->save();

        $res = ResponseModel::where('doc_id', $request->id)->first();
        $res->desc = $request->inputr;
        $res->doc_id = $request->id;
        $res->save();

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->with("failed", "Route update failed." . $e->getMessage());

        }


        return redirect()->route('docs.index');
    }

    public function destroy($id)
    {
        $doc = Doc::find($id);

        DeletedRecord::create([
            "doc_id" => $doc->id,
            "user_id" => auth()->user()->id,
        ]);

        $doc->delete();
        return redirect()->route('docs.index');
    }

    public function transformStringToAarray($string)
    {
        try {
            $first_arr = explode(',', $string);
            $result = [];

            foreach ($first_arr as $key => $arr) {
                list($key, $value) = explode(':', $arr);
                $res = [$key => $value];
                array_push($result, $res);
            }
        } catch (\Throwable) {
            return null;
        }

        return $result;
    }

    public function report()
    {
        $items = Doc::query()
        ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
        ->groupBy('date')
        ->orderBy('date', 'asc') // if you want to order the results by date
        ->get();

        $updated = Doc::query()
        ->where('modified', 1)
        ->selectRaw('DATE(updated_at) as date, COUNT(*) as count')
        ->groupBy('date')
        ->orderBy('date', 'asc') // if you want to order the results by date
        ->get();

        $by = Doc::query()
        ->selectRaw('DISTINCT(modify_by), COUNT(*) as count')
        ->groupBy('modify_by')
        ->orderBy('count', 'desc') // if you want to order the results by date
        ->get();

        $deletedRecords = DeletedRecord::with('user', 'doc')->get();

        $allCounts = Doc::all()->count();
        $updatedCounts = Doc::where('modified', 1)->count();
        $userCounts = User::all()->count();
        $deletedCount = Doc::onlyTrashed()->count();
        $calenderData = Doc::whereYear('created_at', Carbon::now()->year)
        ->selectRaw('DATE(updated_at) as date, COUNT(*) as count')
        ->groupBy('date')
        ->get()->toArray();

        $counts = [
            "Created" => $allCounts,
            "Updated" => $updatedCounts,
            "Deleted" => $deletedCount,
            "Users" => $userCounts
        ];

        return view('reports',  [
            "items" => $items,
            "updated" => $updated,
            "by" => $by,
            "deletedRecords" => $deletedRecords,
            "counts" => $counts,
            "calenderData" => $calenderData
        ]);
    }

    public function restore($id)
    {
        Doc::withTrashed()->where('id', $id)->first()->restore();
        DeletedRecord::where('doc_id', $id)->first()->delete();
        return redirect()->back()->with("success","Route restored");
    }
}
