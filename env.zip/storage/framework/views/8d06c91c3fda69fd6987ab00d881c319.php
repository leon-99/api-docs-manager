<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container">
            <div class="cards my-5">
                <?php $__currentLoopData = $defs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $def): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mt-3">
                        <div class="card-header">
                            <h5 style="font-weight: 600"><?php echo e($def->title); ?></h5>
                            <?php if($def->status == 'Completed'): ?>
                                <p>Feature status: <span class="text-success"><?php echo e($def->status); ?></span></p>
                            <?php elseif($def->status == 'Planned'): ?>
                                <p>Feature status: <span style="color: rgb(219, 155, 37)"><?php echo e($def->status); ?></span></p>
                            <?php elseif($def->status == 'On Hold'): ?>
                                <p>Feature status: <span style="color: rgb(219, 155, 37)"><?php echo e($def->status); ?></span></p>
                            <?php else: ?>
                                <p>Feature status: <span class="text-primary"><?php echo e($def->status); ?></span></p>
                            <?php endif; ?>

                            <small class="text-muted">written by <?php echo e($def->modify_by); ?></small>
                        </div>
                        <div class="card-body">
                            <p class="card-text" style="white-space:pre-wrap"><?php echo e($def->content); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-order-docs\resources\views/definitions.blade.php ENDPATH**/ ?>