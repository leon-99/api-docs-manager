<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                 
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="section my-3" id="<?php echo e($key); ?>">

                <p class="h3" data-bs-toggle="collapse" data-bs-target="#<?php echo e($key); ?>-collapse"
                    aria-expanded="true" aria-controls="<?php echo e($key); ?>-collapse" style="cursor: pointer;">
                    # <?php echo e($key); ?>

                    <span class="material-symbols-outlined me-3" style="float: right">
                        expand_more
                    </span>
                </p>
                <ul class="list-group collapse show ms-4" id="<?php echo e($key); ?>-collapse" aria-expanded="false"
                    aria-controls="<?php echo e($key); ?>-collapse">
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <br id="<?php echo e($key); ?><?php echo e($i->name); ?>">
                        <li class="list-group-item my-3">
                            <div class="dropup">
                                <span class="material-symbols-outlined" type="button" data-bs-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false" style="float: right">
                                    more_horiz
                                </span>

                                <div class="dropdown-menu">

                                    <button class=" dropdown-item text-danger" data-bs-toggle="modal"
                                        data-bs-target="#delete<?php echo e($i->id); ?>">delete</button>

                                    <a href="<?php echo e(route('doc.edit', $i->id)); ?>" class=" dropdown-item">edit</a>
                                </div>
                            </div>
                            <h4 class="mt-3" style="font-weight: 600">
                                <?php if($i->method == 'POST'): ?>
                                    <span class="badge badge-success bg-warning text-dark"><?php echo e($i->method); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-success bg-success"><?php echo e($i->method); ?></span>
                                <?php endif; ?>
                                <span><?php echo e($key); ?>/<?php echo e($i->name); ?></span>
                            </h4>

                            
                            <?php if($i->modified == 0): ?>
                            <p class="text-muted">created <span><?php echo e($i->created_at->diffForHumans()); ?></span> by
                                <?php echo e($i->modify_by); ?></p>
                            <?php else: ?>
                            <p class="text-muted">updated <span><?php echo e($i->updated_at->diffForHumans()); ?></span> by
                                <?php echo e($i->modify_by); ?></p>
                            <?php endif; ?>


                            <!-- Modal -->
                            <div class="modal fade" id="delete<?php echo e($i->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">

                                        <div class="modal-body">
                                            Are you sure you want to delete "<?php echo e($i->group); ?> <?php echo e($i->name); ?>"
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btn-sm"
                                                data-bs-dismiss="modal">Close</button>
                                            <form action="<?php echo e(route('doc.destroy', $i->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <?php if($i->desc[0] == '!'): ?>
                                <p class="my-4 text-danger font-weight-bold" style="white-space:pre-wrap">
                                    <?php echo e($i->desc); ?></p>
                            <?php elseif($i->desc[0] == '?'): ?>
                                <p class="my-4 font-weight-bold" style="white-space:pre-wrap; color: #ac8206">
                                    <?php echo e($i->desc); ?></p>
                            <?php else: ?>
                                <p class="my-4" style="white-space:pre-wrap"><?php echo e($i->desc); ?></p>
                            <?php endif; ?>

                            <div class="my-4">
                                <pre><code><?php echo e($i->url); ?></code></pre>
                            </div>
                            <h5><b>Header</b></h5>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Key</th>
                                        <th scope="col">Value</th>
                                        <th scope="col">Description</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $i->headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($header->key); ?></td>
                                            <td><?php echo e($header->value); ?></td>
                                            <td><?php echo e($header->desc); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <ul class="nav nav-tabs" id="myTab<?php echo e($i->id); ?>" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link text-dark active" id="home-tab" data-bs-toggle="tab"
                                        data-bs-target="#home<?php echo e($i->id); ?>" type="button" role="tab"
                                        aria-controls="home" aria-selected="true"> <span class="material-symbols-outlined ms-2" style="vertical-align: middle;">
                                            data_object
                                            </span> Request</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link text-dark" id="profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#profile<?php echo e($i->id); ?>" type="button" role="tab"
                                        aria-controls="profile" aria-selected="false">Response</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home<?php echo e($i->id); ?>" role="tabpanel"
                                    aria-labelledby="home-tab">

                                    <?php $__currentLoopData = $i->bodies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <pre class="mt-3"><code><?php echo e($b->value); ?></code></pre>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="tab-pane fade" id="profile<?php echo e($i->id); ?>" role="tabpanel"
                                    aria-labelledby="profile-tab">

                                    <?php $__currentLoopData = $i->res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <pre class="mt-3"><code><?php echo e($resp->desc); ?></code></pre>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </li>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-order-docs\resources\views/searchresults.blade.php ENDPATH**/ ?>