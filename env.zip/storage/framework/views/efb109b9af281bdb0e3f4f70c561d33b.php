<?php $__env->startSection('content'); ?>
    <div class="d-flex">
        <div class="col-3 position-fixed" style="width: 250px; height: 100vh; border-right: 1px solid rgb(190, 190, 190)">
            <div class="links mx-2 text-center d-flex flex-column my-4">
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#<?php echo e($group); ?>" class="btn btn-sm btn-dark my-1"><?php echo e($group); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-9 px-5 my-3" style="margin-left: 250px;">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section my-3" id="<?php echo e($key); ?>">

                    <p class="h3" data-bs-toggle="collapse" data-bs-target="#<?php echo e($key); ?>-collapse" aria-expanded="false" aria-controls="<?php echo e($key); ?>-collapse" style="cursor: pointer;">
                        # <?php echo e($key); ?>

                    </p>

                    <ul class="list-group collapse" id="<?php echo e($key); ?>-collapse" aria-expanded="false" aria-controls="<?php echo e($key); ?>-collapse">
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item my-3">
                                <?php if($i->method == 'POST'): ?>
                                    <h5 class="mt-3"><span class="badge badge-success bg-warning">
                                <?php else: ?>
                                    <h5 class="mt-3"><span class="badge badge-success bg-success">
                                <?php endif; ?>
                                <?php echo e($i->method); ?> </span> <?php echo e($i->name); ?>

                                </h5>

                                <pre class="my-5"><code><?php echo e($i->url); ?></code></pre>
                                <h4><b>Header</b></h4>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Key</th>
                                            <th scope="col">Value</th>
                                            <th scope="col">Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $i->headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($header->key); ?></td>
                                                <td><?php echo e($header->value); ?></td>
                                                <td><?php echo e($header->desc); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <h4 class="mt-5"><b>Body</b></h4>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Key</th>
                                            <th scope="col">Value</th>
                                            <th scope="col">Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $i->bodies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($body->key); ?></td>
                                                <td><?php echo e($body->value); ?></td>
                                                <td><?php echo e($body->desc); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <h4 class="mt-5"><b>Response</b></h4>
                                <?php $__currentLoopData = $i->res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <pre><code><?php echo e($resp->desc); ?></code></pre>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\smart-order-docs\resources\views/docs.blade.php ENDPATH**/ ?>