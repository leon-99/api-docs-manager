<?php $__env->startSection('content'); ?>
    <div class="container pb-5">
        <?php if(session('failed')): ?>
            <div class="alert alert-danger mt-3"><?php echo e(@session('failed')); ?></div>
        <?php endif; ?>
        <?php if(session('header_error')): ?>
            <div class="alert alert-danger mt-3"><?php echo e("Header ". session('header_error')); ?></div>
        <?php endif; ?>
        <div class="d-flex justify-content-around">
            <h3 class="my-4 col-md-6">Add New Route</h3>
        </div>

        <form action="<?php echo e(route('doc.store')); ?>" method="post" id="form">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Group</label>
                    <input type="text" class="form-control" id="group" placeholder="Group" name="group" autofocus>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Name</label>
                    <input type="text" class="form-control" id="name" placeholder="name" name="name">
                </div>
            </div>
            <div class="row mb-3">
                <div class="form-group col-md-2">
                    <label>Method</label>
                    <select name="method" class="form-select">
                        <option value="GET">GET</option>
                        <option value="POST">POST</option>
                    </select>
                    
                </div>
                <div class="form-group col-md-10">
                    <label for="endpoint">Endpoint</label>
                    <input type="text" class="form-control" id="endpoint" placeholder="endpoint" name="endpoint">
                </div>
            </div>
            <div class="form-group mb-3">
                <label for="headers">Description</label>
                <textarea type="text" class="form-control" id="desc" placeholder="Describe this route" name="desc">
                </textarea>
                <small>start with ! to mark this as unstable or unused route.</small>
            </div>
            <div class="form-group mb-3">
                <label for="headers">Headar</label>
                <input type="text" class="form-control" id="headers"
                    placeholder="authorition:uicdeiui637,accept:application/json" name="inputh" value="Auth:Barear Token">
                <small>This column works in key value pairs. example name:alice,age:22</small>
                <br>
                <?php if(session('header_error')): ?>
                    <small class="text-danger"><?php echo e(session('header_error')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label for="body">Body</label>
                <textarea type="text" class="form-control" id="body" placeholder="user:1,item_id:2" name="inputb"
                    rows="5"></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="response">Response</label>
                <textarea type="text" class="form-control" id="response" placeholder="[{id:1, text: hello}]" name="response"
                    rows="10"></textarea>
            </div>
            <button type="submit" class="btn btn-success btn-sm">Save</button>
            <p class="col-md-6 my-2 ps-auto text-success d-inline ms-2">Press Ctrl+Enter to save.</p>
        </form>
    </div>

    <script>
        window.addEventListener('keydown', evt => {
            if (evt.key === 'Enter' && evt.ctrlKey) {
                document.querySelector("#form").submit();
            }
        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-order-docs\resources\views/create.blade.php ENDPATH**/ ?>