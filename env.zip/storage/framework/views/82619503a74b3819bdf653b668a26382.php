<?php $__env->startSection('content'); ?>
    <div class="container pb-5">
        <?php if(session('failed')): ?>
            <div class="alert alert-danger mt-3"><?php echo e(@session('failed')); ?></div>
        <?php endif; ?>

        <h3 class="my-4">Update "<?php echo e($item->group); ?>, <?php echo e($item->name); ?>"</h3>

        <form action="<?php echo e(route('doc.update')); ?>" method="post" id="form">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
            <div class="row mb-3">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Group</label>
                    <input type="text" class="form-control" id="group" placeholder="Group" name="group"
                        value="<?php echo e($item->group); ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Name</label>
                    <input type="text" class="form-control" id="name" placeholder="name" name="name"
                        value="<?php echo e($item->name); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <div class="form-group col-md-6">
                    <label for="endpoint">Method</label>
                    <input type="text" class="form-control" id="method" placeholder="GET/POST" name="method"
                        value="<?php echo e($item->method); ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="endpoint">Endpoint</label>
                    <input type="text" class="form-control" id="endpoint" placeholder="endpoint" name="endpoint"
                        value="<?php echo e($item->url); ?>">
                </div>
            </div>
            <div class="form-group mb-3">
                <label for="headers">Description</label>
                <textarea type="text" class="form-control" id="desc" name="desc"><?php echo e($item->desc); ?></textarea>
                <small>start with ! to mark this as unstable or unused route.</small>
                <br>
                <?php if(session('header_error')): ?>
                    <small class="text-danger"><?php echo e(session('header_error')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label for="headers">Headar</label>
                <input type="text" class="form-control" id="headers"
                    placeholder="authorition:uicdeiui637,accept:application/json" name="inputh" value="Auth:Barear Token">
                <small>This column works in key value pairs. example name:alice,age:22</small>
            </div>
            <div class="form-group mb-3">
                <label for="body">Body</label>
                <textarea type="text" class="form-control" id="body" placeholder="user:1,item_id:2" name="inputb"
                    rows="5"><?php echo e($item->bodies[0]->value); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="response">Response</label>
                <textarea type="text" class="form-control" id="response" placeholder="[{id:1, text: hello}]" name="inputr"
                    rows="10"><?php echo e($item->res[0]->desc); ?></textarea>
            </div>
            <button type="submit" class="btn btn-success btn-sm">Save</button>
            <p class="col-md-6 my-2 ps-auto text-success d-inline ms-2">Press Ctrl+Enter to save.</p>
        </form>
    </div>

    <script>
        window.addEventListener('keydown', evt => {
            if (evt.key === 'Enter' && evt.ctrlKey) {
                document.querySelector("#form").submit();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-order-docs\resources\views/update.blade.php ENDPATH**/ ?>